#memo_decor.py
"""This module is assignment 1:problem 7
"""
def memoize(func):
    """ This is a decorator used for keeping the memory of any recursive call.
    """
    mem = {}
    def function_do(*args):
        key = str(args)
        if key not in mem:
            mem[key] = func(*args)
        return mem[key]
    return function_do
@memoize
def fib(number):
    """Fibbonaci seq.
    """
    if number == 0:
        return 0
    if number == 1:
        return 1
    return fib(number-1)+fib(number-2)
@memoize
def n_choose_r(number, choose):
    """Binomial coefficient as a recursive program
    """
    if choose == 0:
        return 1
    if number == choose:
        return 1
    return n_choose_r(number-1, choose-1) + n_choose_r(number-1, choose)
