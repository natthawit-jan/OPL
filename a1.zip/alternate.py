def iter_alternate(iter1, iter2):
    while True:
        try:
            yield next(iter1)
            yield next(iter2)
        except:
            try:
                 yield next(iter1)
            except:
                yield next(iter2)
def sqaure(n=1):
    while True:
        yield n*n
        n+= 1
def sumA(n=1):
    while True:
        yield n
        n+=n  

iter1 = iter([4,2,1,23,4,6,7])
iter2 = iter([-4,34])

mySq = sqaure()
mySum = sumA()

gen = iter_alternate(mySq, iter1)





