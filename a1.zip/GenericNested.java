import javafx.util.Pair;

import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class GenericNestedList<E> implements NestedList<E> {
    E data;
    List<NestedList<E>> nestedLists;


    public GenericNestedList(List<NestedList<E>> nestedLists) {
        this.nestedLists = nestedLists;
    }

    public GenericNestedList(E data) {

        this.data = data;

    }


    @Override
    public boolean isBase() {
        return data != null;


    }

    @Override
    public E getBaseValue() {
        if (isBase()) return data;
        throw new IllegalStateException();

    }

    @Override
    public List<NestedList<E>> getList() {
        if (!isBase())
            return nestedLists;
        throw new IllegalStateException();

    }

    public Iterator<Pair<E, Integer>> iterator() {
        return new InteratorNested();
    }


    public class InteratorNested implements Iterator<Pair<E, Integer>> {


        BlockingQueue<Pair<E, Integer>> blockingQueue;

        public InteratorNested() {
            this.blockingQueue = new ArrayBlockingQueue<>(10);
            for (NestedList<E> lst : nestedLists) {
                try {
                    walkNested(lst, 0);
                } catch (InterruptedException exception) {
                    exception.printStackTrace();
                }
            }


        }


        @Override
        public boolean hasNext() {
            return !blockingQueue.isEmpty();
        }

        @Override
        public Pair<E, Integer> next() {
            try {
                return blockingQueue.take();
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
            return null;
        }

        void walkNested(NestedList<E> list, int depth) throws InterruptedException {
            if (list.isBase()) {
                blockingQueue.put(new Pair<>(list.getBaseValue(), depth));
                Thread.sleep(10);
            }
            else {
                for (NestedList<E> member : list.getList())
                    walkNested(member, depth + 1);
            }

        }


        }


}
