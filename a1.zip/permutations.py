#permutation.py
""" This module is used to yield the permutaion.
"""
def all_perms(number):
    """ this method is the start
    """
    passing_range = range(1, number+1)
    passing_range = map(str, passing_range)
    return helper(list(passing_range))
def helper(my_lst):
    """ This method called recursively to retrive the first element
    and the rest.
    """
    if len(my_lst) == 1:
        yield (int(my_lst[0]),)
    for first_element in my_lst:
        remaining_elements = [int(x) for x in my_lst if x != first_element]
        rem = helper(remaining_elements)
        for the_rest in rem:
            perm = (int(first_element),)+the_rest
            yield perm
