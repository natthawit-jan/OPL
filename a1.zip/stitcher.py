""" method
"""
def stitch_files(*args):
    """ This method is used to stitch all files together
    """
    for file in args:
        if  not file.lower().endswith('.txt'):
            raise ValueError(f'{file} is not .txt file')
        with open(file, 'r') as my_file:
            data = my_file.readlines()
            for line in data:
                try:
                    yield line
                except IOError as exception:
                    raise exception
