import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class Alternate<E> implements Iterable<E> {
//    Iterable<E> iter1, iter2;
    Iterator<E> iterator1, iterator2;
    boolean startWithTheFirstIter;
    
    public Alternate(Iterable<E> iter1, Iterable<E> iter2) {
        this.startWithTheFirstIter = true; // will be toggled later
        this.iterator1 = iter1.iterator();
        this.iterator2= iter2.iterator();
    }

    public Iterator<E> iterator() {
        return new Iterator<E>() {
            @Override
            public boolean hasNext() {
                return iterator1.hasNext() || iterator2.hasNext();
            }

            @Override
            public E next() {
                E rt =   (startWithTheFirstIter) ? iterator1.next(): iterator2.next();
                startWithTheFirstIter = !startWithTheFirstIter; // toggled
                return rt;

            }
        };
    }


    public static void main(String[] args) {
        List<Integer> it1 = Arrays.asList(3, 5, 9); 
        List<Integer> it2 = Arrays.asList(4, 1, 6);
         for (Integer e: new Alternate<>(it1, it2)) {
             System.out.println(e);
        
    }



}


}
