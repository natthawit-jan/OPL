object TurnIt extends App {
  def transpose(A: List[List[Int]]): List[List[Int]] = A match {
    case h::t if h.isEmpty => Nil
    case _ => {
      val split = getHead(A)
      split._1::transpose(split._2)
    }
  }
  def getHead(A: List[List[Int]]): (List[Int], List[List[Int]]) = A match {
    case Nil => (Nil, Nil)
    case h::t => {
      val extract = getHead(t)
      (h.head::extract._1, h.tail::extract._2)
    }
  }






}
