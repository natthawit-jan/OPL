object Factorial extends App {
  def factorial(n: Int): Long = {
    def factorial_helper(n: Int, prod: Int): Int = n match {
      case 0 => prod
      case _ => factorial_helper(n-1, n*prod)
    }
    factorial_helper(n,1)
  }




}





