object Zombies extends App {
  def countBad(hs: List[Int]): Int = {
    def CountBadHelper(list : List[Int]) : (Int, List[Int]) =  {
      if (list.length <= 1){
        (0, list)
      }
      else {
        val (left, right) = list splitAt (list.length / 2)
        val (inversionLeft, l) = CountBadHelper(left)
        val (inversionRight, r) = CountBadHelper(right)
        val (inversionBetween, mergeList) = merge(l, r, 0)
        (inversionLeft + inversionRight + inversionBetween, mergeList)
      }
    }
        def merge(leftList: List[Int], rightList: List[Int], count: Int) : (Int, List[Int]) = (leftList, rightList) match {
          case (Nil, r) => (count, r)
          case (l, Nil) => (count, l)
          case (leftHead::leftTail, rightHead::rightTail) => {
            if (leftHead >= rightHead){
              val (lcount, list) = merge(leftTail, rightList, count)
            (count + lcount, leftHead :: list)
          } else {
              val (rcount, list) = merge(leftList, rightTail, count)
              (count + leftList.length + rcount, rightHead :: list)
            }
          }
        }


//    val result = CountBadHelper(hs)

    CountBadHelper(hs)._1


  }






}
