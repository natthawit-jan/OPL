object Happy extends App {
  // todo: write these functions!
  def sumOfDigitsSquared(n: Int): Int =  {
    def sumDigitHelper(n: Int, tenth: Int, ans: Int ): Int = tenth match {
      case 0 => ans
      case _ => sumDigitHelper(n%tenth, tenth/10, (n/tenth)*(n/tenth)+ans)
    }

    sumDigitHelper(n, math.pow(10, n.toString.length-1).toInt, 0)
  }
  def isHappy(n: Int): Boolean = n match {
    case 1 => true
    case 4 => false
    case _ => isHappy(sumOfDigitsSquared(n))

  }
  def kThHappy(k: Int): Int = {
    def kHelper(k: Int, start: Int) : Int = k match {
      case 0 => start-1
      case _ => {
        val bool = isHappy(start)
        if (bool)
          kHelper(k-1, start+1)
          else
        kHelper(k, start+1)
        }
      }

    kHelper(k, 1)
  }

}


