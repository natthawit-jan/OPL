object Aggregate extends App {
  // todo: implement these functions for real!
  def myMin(p: Double, q: Double, r: Double): Double = {
    val minSofar = Double.MaxValue
    val xs = List(p,q,r)
    def myMinHelper(xs: List[Double], minSofar: Double) :Double = xs match {
      case  Nil => minSofar
      case h::t if h < minSofar => myMinHelper(t,h)
      case _ => myMinHelper(xs.tail, minSofar)
    }
    myMinHelper(xs, minSofar)
  }

  def myMean(p: Double, q: Double, r: Double): Double = {
    val xs = List(p, q, r)
    def myMeanHelper(xs: List[Double], sum: Double) : Double = xs match {
      case Nil => sum/3.0
      case h::t => myMeanHelper(t, sum+h)
    }
    myMeanHelper(xs, 0)
  }

  def myMed(p: Double, q: Double, r: Double): Double = p match {
    case p if p < q => q match {
      case q if q > r => q
      case _ => r
    }
    case _ => r match {
      case r if r < p => r
      case _ => p

    }
  }




}
